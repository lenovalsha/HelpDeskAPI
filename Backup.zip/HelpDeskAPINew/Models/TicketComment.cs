﻿namespace HelpDeskAPINew.Models
{
    public class TicketComment
    {
        public int Id { get; set; }
        public string Comment { get; set; }
        public DateTime CreatedAt { get; set; }
        public Staff Staff { get; set; }
        //public Ticket Ticket { get; set; }
    }
}
