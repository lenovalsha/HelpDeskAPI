﻿namespace HelpDeskAPINew.Models
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Staff>? Staff { get; set; }

        public Department()
        {
            Staff = new List<Staff>();
        }

    }
}
