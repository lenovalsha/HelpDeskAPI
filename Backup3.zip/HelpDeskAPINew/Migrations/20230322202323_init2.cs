﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HelpDeskAPINew.Migrations
{
    /// <inheritdoc />
    public partial class init2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Ticket_Staff_StaffName",
                table: "Ticket");

            migrationBuilder.AlterColumn<string>(
                name: "StaffName",
                table: "Ticket",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddForeignKey(
                name: "FK_Ticket_Staff_StaffName",
                table: "Ticket",
                column: "StaffName",
                principalTable: "Staff",
                principalColumn: "Name");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Ticket_Staff_StaffName",
                table: "Ticket");

            migrationBuilder.AlterColumn<string>(
                name: "StaffName",
                table: "Ticket",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Ticket_Staff_StaffName",
                table: "Ticket",
                column: "StaffName",
                principalTable: "Staff",
                principalColumn: "Name",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
