﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HelpDeskAPINew.Migrations
{
    /// <inheritdoc />
    public partial class init6 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Staff_Departments_DepartmentId1",
                table: "Staff");

            migrationBuilder.DropIndex(
                name: "IX_Staff_DepartmentId1",
                table: "Staff");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Departments",
                table: "Departments");

            migrationBuilder.DropColumn(
                name: "DepartmentId",
                table: "Staff");

            migrationBuilder.DropColumn(
                name: "DepartmentId1",
                table: "Staff");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "Departments");

            migrationBuilder.AddColumn<string>(
                name: "DepartmentName",
                table: "Staff",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Departments",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Departments",
                table: "Departments",
                column: "Name");

            migrationBuilder.CreateIndex(
                name: "IX_Staff_DepartmentName",
                table: "Staff",
                column: "DepartmentName");

            migrationBuilder.AddForeignKey(
                name: "FK_Staff_Departments_DepartmentName",
                table: "Staff",
                column: "DepartmentName",
                principalTable: "Departments",
                principalColumn: "Name");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Staff_Departments_DepartmentName",
                table: "Staff");

            migrationBuilder.DropIndex(
                name: "IX_Staff_DepartmentName",
                table: "Staff");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Departments",
                table: "Departments");

            migrationBuilder.DropColumn(
                name: "DepartmentName",
                table: "Staff");

            migrationBuilder.AddColumn<string>(
                name: "DepartmentId",
                table: "Staff",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "DepartmentId1",
                table: "Staff",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Departments",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "Departments",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Departments",
                table: "Departments",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_Staff_DepartmentId1",
                table: "Staff",
                column: "DepartmentId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Staff_Departments_DepartmentId1",
                table: "Staff",
                column: "DepartmentId1",
                principalTable: "Departments",
                principalColumn: "Id");
        }
    }
}
